from setuptools import setup, find_packages

setup(
  name='srdata',
  version='1.0.0',
  author="Wataru Zama",
  packages=find_packages(),
  include_package_data=True
)