# srdataについて

製作者: Wataru Zama

**srdata**(Software reliability dataset)は，ソフトウェアフォールト発見数データやソフトウェアフォールト発見時間間隔データといった，ソフトウェア信頼性に関連するデータを提供します．

詳しい使い方はsrdata/examples/example_usage.pyをご覧ください．
